# v5.10.18-test ReleaseQA / DirectZIP / GPUFull 差分

- 基準は前回Codex v5.10.17-test（codex/lol-autocine-v51017-camera-evidence-badgeqa-handoff）。
- 別版へ丸ごと上書きせず、変更を保存してgit apply --check CHANGES_v5.10.18_ReleaseQA_DirectZIP_GPUFull.patch、その後git apply。単体AutoCine Gitでは-p2を追加。
- 完全版は旧版と別フォルダへ展開。設定/録画は削除しない。
- 内容・実機確認: docs/CODEX_INTEGRATION_v51018_JA.md、docs/WINDOWS_TEST_v51018_JA.md。
