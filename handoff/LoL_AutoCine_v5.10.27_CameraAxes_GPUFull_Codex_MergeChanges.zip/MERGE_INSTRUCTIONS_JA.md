# v5.10.27-test カメラ軸・独立モード / GPUFull 差分

- 基準は前回Codex v5.10.26-test（codex/lol-autocine-v51026-single-qa-button）。
- 別版へ丸ごと上書きせず、変更を保存してgit apply --check CHANGES_v5.10.27_CameraAxes_GPUFull.patch、その後git apply。単体AutoCine Gitでは-p2を追加。
- 完全版は旧版と別フォルダへ展開。設定/録画は削除しない。
- 内容・実機確認: docs/CODEX_INTEGRATION_v51027_JA.md、docs/WINDOWS_TEST_v51027_JA.md、docs/CAMERAQA_30MB_DEV_JA.md。
