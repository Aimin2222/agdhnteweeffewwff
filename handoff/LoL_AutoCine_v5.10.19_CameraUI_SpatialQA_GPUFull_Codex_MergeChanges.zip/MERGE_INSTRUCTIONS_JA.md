# v5.10.19-test CameraUI / SpatialQA / GPUFull 差分

- 基準は前回Codex v5.10.18-test（codex/lol-autocine-v51018-releaseqa-directzip-handoff）。
- 別版へ丸ごと上書きせず、変更を保存してgit apply --check CHANGES_v5.10.19_CameraUI_SpatialQA_GPUFull.patch、その後git apply。単体AutoCine Gitでは-p2を追加。
- 完全版は旧版と別フォルダへ展開。設定/録画は削除しない。
- 内容・実機確認: docs/CODEX_INTEGRATION_v51019_JA.md、docs/WINDOWS_TEST_v51019_JA.md。
