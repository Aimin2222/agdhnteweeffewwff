# v5.10.15 ScanUI_DOF_Checkbox_CameraFix / GPUFull の差分

- 基準: codex/lol-autocine-v51015-portrait-crashfix-handoff（前回Codex統合v5.10.15）。別版への単純上書きはしない。
- GPU側core/kill_icons.pyの表示名だけ変更し全旧名とPlayer互換を保持。スキャン一本化、DOF/チェック表示、カメラ校正リセット、開発用録画テストを統合。GPUエンジン/音声は保持。
- 変更をコミットしてからgit apply --check CHANGES_v5.10.15_ScanUI_DOF_Checkbox_CameraFix_GPUFull.patch、続いてgit applyで適用。
- 単体AutoCineのGitルートでは上記2コマンドに-p2を追加。
- 全体を取得する場合は完全版ZIPを旧版と別フォルダへ展開。設定/録画/プロジェクトを削除しない。
- Windows実機テスト: docs/WINDOWS_TEST_SCANFIX_v51015_JA.md。
