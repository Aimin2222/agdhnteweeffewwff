# v5.10.15 GPU映像処理とホットフィックスの統合の差分

- 基準: `codex/lol-autocine-v51014-studio-gpu-handoff`（v5.10.14 PlayerFilter GPUFull）
- テキスト変更ファイルは `LoL_AutoCine/` 以下。PNG素材は重複容量を避け、Git binary patchにのみ収録。パッチ適用でPNGも復元される。単なるファイル上書きでは統合が完了しない。
- Git推奨: 既存変更をコミットしてから差分を検査して適用する。GitHub取得用リポジトリのルートでは `git apply --check CHANGES_v5.10.15_UI_Scan_Camera_GPUFull.patch` → `git apply CHANGES_v5.10.15_UI_Scan_Camera_GPUFull.patch`。
- AutoCine単体のGitルート（直下にcore/やSTART.batがある構成）では `git apply --check -p2 CHANGES_v5.10.15_UI_Scan_Camera_GPUFull.patch` → `git apply -p2 CHANGES_v5.10.15_UI_Scan_Camera_GPUFull.patch`。
- 今回はv5.10.15の独立編集ページ・右側スキャン操作・素材名・非同期実フレーム比較/公式チャンピオン画像・RED限定カメラ調整を統合。変更検査後にGitパッチで適用するか、新しい完全版を別フォルダへ展開する。
- Codexが別途編集した `core/effects.py`、`core/gpu_pipeline.py`、`core/jobs.py`、`core/camera.py` 等はコンフリクト確認必須
- 音声のProcess Loopback、NVENC、TargetLock、UI設定の回帰テストを実施
- Windows/LoL/NVIDIA実機テストは配布前のLinux CIとは別に行う
