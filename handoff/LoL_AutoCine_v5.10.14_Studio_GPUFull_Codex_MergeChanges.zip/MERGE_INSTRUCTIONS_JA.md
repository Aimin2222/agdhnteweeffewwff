# v5.10.14 GPU映像処理とホットフィックスの統合の差分

- 基準: `codex/lol-autocine-v51013-match-camera-handoff`（v5.10.13 PlayerFilter GPUFull）
- テキスト変更ファイルは `LoL_AutoCine/` 以下。PNG素材は重複容量を避け、Git binary patchにのみ収録。パッチ適用でPNGも復元される。単なるファイル上書きでは統合が完了しない。
- Git推奨: 既存変更をコミットしてから差分を検査して適用する。GitHub取得用リポジトリのルートでは `git apply --check CHANGES_v5.10.14_Studio_GPUFull.patch` → `git apply CHANGES_v5.10.14_Studio_GPUFull.patch`。
- AutoCine単体のGitルート（直下にcore/やSTART.batがある構成）では `git apply --check -p2 CHANGES_v5.10.14_Studio_GPUFull.patch` → `git apply -p2 CHANGES_v5.10.14_Studio_GPUFull.patch`。
- 今回はv5.10.14の5作業領域・折りたたみUI・キルフレーム図鑑・比較プレビューと切替演出9種類のGPU接続を統合。変更検査後にGitパッチで適用するか、新しい完全版を別フォルダへ展開する。
- Codexが別途編集した `core/effects.py`、`core/gpu_pipeline.py`、`core/jobs.py`、`core/camera.py` 等はコンフリクト確認必須
- 音声のProcess Loopback、NVENC、TargetLock、UI設定の回帰テストを実施
- Windows/LoL/NVIDIA実機テストは配布前のLinux CIとは別に行う
