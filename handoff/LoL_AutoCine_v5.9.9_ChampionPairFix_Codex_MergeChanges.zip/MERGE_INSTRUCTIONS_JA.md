# v5.9.9 ChampionPairFix Codex統合用差分

- 基準: `codex/lol-autocine-v599-handoff`（前回のv5.9.9）
- 変更ファイル: このZIPに含まれる `LoL_AutoCine/` 以下
- Git推奨: 既存変更をコミットしてから差分を検査して適用する。GitHub取得用リポジトリのルートでは `git apply --check CHANGES_v5.9.9.patch` → `git apply CHANGES_v5.9.9.patch`。
- AutoCine単体のGitルート（直下にcore/やSTART.batがある構成）では `git apply --check -p2 CHANGES_v5.9.9.patch` → `git apply -p2 CHANGES_v5.9.9.patch`。
- Gitを使わない場合: 一覧を比較してから各ファイルをマージ（自動上書きは推奨しない）
- Codexが別途編集した `core/effects.py`、`core/gpu_pipeline.py`、`core/jobs.py`、`core/camera.py` 等はコンフリクト確認必須
- 音声のProcess Loopback、NVENC、TargetLock、UI設定の回帰テストを実施
- Windows/LoL/NVIDIA実機テストは配布前のLinux CIとは別に行う
