# v5.10.17-test CameraEvidence / BadgeQA / GPUFull 差分

- 基準は前回Codex v5.10.16-test（codex/lol-autocine-v51016-motion-cameraqa-handoff）。
- 別版へ丸ごと上書きせず、変更を保存してgit apply --check CHANGES_v5.10.17_CameraEvidence_BadgeQA_GPUFull.patch、その後git apply。単体AutoCine Gitでは-p2を追加。
- 完全版は旧版と別フォルダへ展開。個人設定/録画は削除しない。
- 内容・実機確認: docs/CODEX_INTEGRATION_v51017_JA.md、docs/WINDOWS_TEST_v51017_JA.md。
