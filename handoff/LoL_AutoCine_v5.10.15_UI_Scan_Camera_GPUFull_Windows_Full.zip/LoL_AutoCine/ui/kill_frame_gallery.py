# -*- coding: utf-8 -*-
"""Full kill-frame gallery independent of the current LoL replay.

Keeps game/video thread untouched. UI thumbnails are generated in small batches
from the same core.kill_icons.make_badge renderer used for exported videos.
"""
from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from queue import Queue, Empty
from threading import Thread, Event
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageTk, ImageDraw

from core.kill_icons import STYLES, make_badge, ASSET_STYLES
from ui.live_preview import LatestPreview


def sample_portrait(rgb, name: str):
    """Neutral sample portrait; never impersonates a LoL champion or a live scene."""
    canvas = Image.new("RGB", (180, 180), rgb)
    d = ImageDraw.Draw(canvas)
    d.ellipse((30, 20, 150, 140), fill=tuple(min(255,x+40) for x in rgb))
    d.rounded_rectangle((42, 120, 138, 185), radius=22, fill=tuple(max(0,x-25) for x in rgb))
    d.text((9, 8), name, fill=(245, 245, 250))
    return canvas



def render_badge(style, glow_strength=1., glow_enabled=True):
    # Each request owns its temporary files. Closing a window never deletes
    # files still in use by thumbnail/preview workers.
    with TemporaryDirectory(prefix='autocine_badge_preview_') as folder:
        root=Path(folder);a=root/'a.png';b=root/'b.png'
        sample_portrait((57,109,191),'A').save(a)
        sample_portrait((177,65,97),'B').save(b)
        tmp=root/'badge.png'
        if style == 'off':
            image=Image.new('RGBA',(385,116),(0,0,0,0))
            ImageDraw.Draw(image).text((128,51),'NO FRAME',fill='white')
            return image
        make_badge(tmp,style,killer_icon=a,victim_icon=b,glow_strength=glow_strength,
                   glow_enabled=glow_enabled,hires=style in ASSET_STYLES)
        with Image.open(tmp) as image:return image.convert('RGBA').copy()


def render_preview(request):
    try:
        style,strength,enabled=request
        image=render_badge(style,strength,enabled)
        compact=image.copy();compact.thumbnail((460,175),Image.Resampling.LANCZOS)
        zoom=image.resize((770,232),Image.Resampling.LANCZOS)
        return compact,zoom,''
    except Exception as error:
        return None,None,str(error)


def render_thumbnails(ready, stop):
    # Only a plain queue and stop event cross the thread boundary, no App/Tk.
    for style in STYLES:
        if stop.is_set():return
        try:
            picture=render_badge(style)
            picture.thumbnail((280,92),Image.Resampling.LANCZOS)
            ready.put((style,picture,None))
        except Exception as error:
            ready.put((style,None,str(error)))


def display_name(style):
    return STYLES.get(style, style)


class KillFrameGallery:
    """Searchable scrollable 2-column gallery with a right-side large preview."""
    def __init__(self, app):
        self.app=app
        self.win=tk.Toplevel(app.root)
        self.win.title("LoL AutoCine｜キルフレーム図鑑")
        self.win.geometry("1080x740")
        self.win.minsize(740, 500)
        self.win._kill_gallery=self
        self._photos=[]
        self._queue=list(STYLES)
        self._ready=Queue()
        self._stopping=False
        self._stop_event=Event()
        self._preview_after=None
        current=app.var_kill_icon_style.get()
        self._chosen=next((code for code,label in STYLES.items() if label==current),'premium_gold')
        self._preview_worker=LatestPreview(render_preview)
        self._preview_generation=0
        self._preview_presented=None
        self._zoom_window=None
        self._poll_after=None
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind('<Destroy>',self._on_destroy,add='+')

        heading=ttk.Frame(self.win,padding=10)
        heading.pack(fill="x")
        ttk.Label(heading,text="キルフレーム図鑑",font=("Meiryo UI",15,"bold")).pack(side="left")
        ttk.Label(heading,text="試合の撮影は不要。選択後はかんたん編集・詳細編集の両方に反映。",
                  wraplength=460).pack(side="left",padx=(18,4))
        self.search=tk.StringVar()
        self.group=tk.StringVar(value="すべて")
        self.groups=("すべて","追加素材","ゴールド・炎","ネオン・サイバー","スキンテーマ風","その他")
        ttk.Combobox(heading,textvariable=self.group,values=self.groups,state="readonly",width=17).pack(side="right",padx=(7,4))
        self.group.trace_add("write",self.filter_cards)
        ttk.Entry(heading,textvariable=self.search,width=22).pack(side="right")
        ttk.Label(heading,text="検索：",style="CardMuted.TLabel").pack(side="right")
        main=ttk.PanedWindow(self.win,orient="horizontal")
        main.pack(fill="both",expand=True)
        left=ttk.Frame(main)
        right=ttk.Frame(main,padding=12)
        main.add(left,weight=3);main.add(right,weight=2)
        self.canvas=tk.Canvas(left,background="#F6F7F9",highlightthickness=0)
        bar=ttk.Scrollbar(left,orient="vertical",command=self.canvas.yview)
        self.grid_parent=ttk.Frame(self.canvas)
        self.grid_parent.bind("<Configure>",lambda _e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.grid_id=self.canvas.create_window((0,0),window=self.grid_parent,anchor="nw")
        self.canvas.bind("<Configure>",lambda e:self.canvas.itemconfigure(self.grid_id,width=e.width))
        self.canvas.configure(yscrollcommand=bar.set)
        self.canvas.pack(side="left",fill="both",expand=True)
        bar.pack(side="right",fill="y")
        self.cards=[]
        for idx,(style,title) in enumerate(STYLES.items()):
            panel=ttk.Frame(self.grid_parent,padding=7,style="Card.TFrame")
            panel.grid(row=idx//2,column=idx%2,sticky="nsew",padx=4,pady=4)
            ttk.Label(panel,text=title,wraplength=290).pack(anchor="w")
            image=ttk.Label(panel,text="プレビュー準備中…",cursor="hand2")
            image.pack(fill="x")
            image.bind("<Button-1>",lambda _e,s=style:self.select(s))
            ttk.Button(panel,text="選択・適用",command=lambda s=style:self.select(s,apply=True)).pack(fill="x",pady=(3,0))
            self.cards.append((style,title,panel,image))
        self.grid_parent.columnconfigure(0,weight=1)
        self.grid_parent.columnconfigure(1,weight=1)
        self.search.trace_add("write",self.filter_cards)
        self.canvas.bind("<MouseWheel>",self._wheel)
        self.grid_parent.bind("<MouseWheel>",self._wheel)
        for _,_,panel,im in self.cards:
            panel.bind("<MouseWheel>",self._wheel)
            im.bind("<MouseWheel>",self._wheel)
        ttk.Label(right,text="大きく確認",font=("Meiryo UI",12,"bold")).pack(anchor="w")
        self.title=ttk.Label(right,text="",wraplength=440)
        self.title.pack(anchor="w",pady=(4,8))
        self.preview=ttk.Label(right,text="読み込み中…")
        self.preview.pack(fill="x",pady=(6,8))
        ttk.Button(right,text="▣ さらに拡大して確認",command=self.zoom_preview).pack(fill="x",pady=(0,8))
        ttk.Label(right,text="青／赤は見本の肖像です。実際の書き出しでは試合のチャンピオンアイコンになります。",
                  wraplength=410).pack(anchor="w")
        self.strength=tk.DoubleVar(value=float(app.var_kill_glow_strength.get()))
        ttk.Label(right,text="発光量（0〜2）").pack(anchor="w",pady=(12,1))
        ttk.Scale(right,variable=self.strength,from_=0,to=2,command=lambda _s:self._queue_preview()).pack(fill="x")
        self.glow_enabled=tk.BooleanVar(value=app.var_kill_glow_enabled.get())
        ttk.Checkbutton(right,text="追加発光をON",variable=self.glow_enabled,command=self._queue_preview).pack(anchor="w")
        ttk.Button(right,text="このフレームを適用",style="Accent.TButton",
                   command=lambda:self.select(self._chosen,apply=True)).pack(fill="x",pady=(10,5))
        ttk.Button(right,text="閉じる",command=self.close).pack(fill="x")
        self.status=ttk.Label(right,text="37種類以上を順に読み込んでいます。",wraplength=430)
        self.status.pack(anchor="w",pady=7)
        self.select(self._chosen)
        Thread(target=render_thumbnails,args=(self._ready,self._stop_event),daemon=True,name="AutoCine-KillFrames").start()
        self._poll_after=self.win.after(30,self._fill_batch)

    def _fill_batch(self):
        if not self.win.winfo_exists() or self._stopping:return
        for _ in range(3):
            try:style,im,error=self._ready.get_nowait()
            except Empty:break
            if style in self._queue:self._queue.remove(style)
            for key,_,_,label in self.cards:
                if key==style:
                    if error:label.configure(text="プレビュー不可: "+error)
                    else:
                        photo=ImageTk.PhotoImage(im,master=self.win)
                        self._photos.append(photo)
                        label.configure(image=photo,text="")
                    break
        self.status.configure(text=f"読み込み：{len(STYLES)-len(self._queue)} / {len(STYLES)}")
        result=self._preview_worker.result(self._preview_generation)
        if result is not None and result is not self._preview_presented:
            self._preview_presented=result
            compact,large,error=result[1]
            if error:
                self.preview.configure(image='',text='プレビュー不可: '+error)
                if self._zoom_window is not None and self._zoom_window.winfo_exists():
                    self._zoom_window._preview.configure(image='',text='プレビュー不可: '+error)
                self._poll_after=self.win.after(45,self._fill_batch)
                return
            self._main_photo=ImageTk.PhotoImage(compact,master=self.win)
            self.preview.configure(image=self._main_photo,text='')
            if self._zoom_window is not None and self._zoom_window.winfo_exists():
                photo=ImageTk.PhotoImage(large,master=self._zoom_window)
                self._zoom_window._photo=photo
                self._zoom_window._preview.configure(image=photo,text='')
        self._poll_after=self.win.after(45,self._fill_batch)

    def _queue_preview(self):
        self._preview_generation+=1  # invalidate results even during debounce
        if self._preview_after:
            self.win.after_cancel(self._preview_after)
        self._preview_after=self.win.after(180,self._refresh_preview)

    def _refresh_preview(self):
        self._preview_after=None
        if self._stopping or not self.win.winfo_exists():return
        self._preview_worker.submit(self._preview_generation,
            (self._chosen,float(self.strength.get()),bool(self.glow_enabled.get())))

    def select(self,style,apply=False):
        if style not in STYLES:return
        self._chosen=style
        self.title.configure(text=f"{STYLES[style]} — {'素材型・高画質' if style in ASSET_STYLES else '描画型'}")
        self._queue_preview()
        if apply:
            self.app.var_kill_icon_style.set(STYLES[style])
            self.app.var_kill_glow_strength.set(float(self.strength.get()))
            self.app.var_kill_glow_enabled.set(bool(self.glow_enabled.get()))
            self.app._save_settings()
            self.app.log("キルフレーム図鑑から適用: "+STYLES[style])

    def zoom_preview(self):
        if self._zoom_window is not None and self._zoom_window.winfo_exists():
            self._zoom_window.lift()
        else:
            popup=self._zoom_window=tk.Toplevel(self.win)
            popup.title("キルフレームを大きく確認")
            popup.geometry("860x330")
            ttk.Label(popup,text=STYLES[self._chosen],font=("Meiryo UI",13,"bold")).pack(pady=8)
            popup._preview=ttk.Label(popup,text='比較画像を準備中…')
            popup._preview.pack(pady=6)
        self._queue_preview()

    def _category(self, style):
        if style.startswith("user_frame_"):return "追加素材"
        if any(x in style for x in ("gold","royal","inferno","noon","wing")):return "ゴールド・炎"
        if any(x in style for x in ("neon","cyber","project","crystal")):return "ネオン・サイバー"
        if any(x in style for x in ("kda","star","spirit","celestial")):return "スキンテーマ風"
        return "その他"

    def filter_cards(self,*_):
        token=self.search.get().strip().casefold()
        group=self.group.get()
        idx=0
        for style,title,panel,_ in self.cards:
            if (not token or token in title.casefold() or token in style.casefold()) and (group=="すべて" or group==self._category(style)):
                panel.grid(row=idx//2,column=idx%2,sticky="nsew",padx=4,pady=4)
                idx+=1
            else:panel.grid_remove()
        self.canvas.yview_moveto(0)

    def _wheel(self,e):
        d=getattr(e,'delta',0)
        n=-int(d/120) if d else (-3 if getattr(e,'num',0)==4 else 3)
        self.canvas.yview_scroll(n,"units")
        return "break"

    def _on_destroy(self,event):
        if event.widget is self.win:self._stop_workers()

    def _stop_workers(self):
        if self._stopping:return
        self._stopping=True
        self._stop_event.set()
        self._preview_worker.close()
        for task in (self._preview_after,self._poll_after):
            if task:
                try:self.win.after_cancel(task)
                except tk.TclError:pass
        self._preview_after=self._poll_after=None

    def close(self):
        self._stop_workers()
        if self.win.winfo_exists():self.win.destroy()


def open_gallery(app):
    previous=getattr(app,'_kill_frame_gallery',None)
    if previous and previous.win.winfo_exists():
        previous.win.lift()
        return previous.win
    app._kill_frame_gallery=KillFrameGallery(app)
    return app._kill_frame_gallery.win
