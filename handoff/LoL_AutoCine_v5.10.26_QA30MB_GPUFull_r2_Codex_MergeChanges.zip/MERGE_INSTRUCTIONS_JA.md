# v5.10.26-test CameraUI / SpatialQA / GPUFull 差分

- 基準は前回Codex v5.10.25-test（codex/lol-autocine-v51025-blue6-reference-handoff）。
- 別版へ丸ごと上書きせず、変更を保存してgit apply --check CHANGES_v5.10.26_QA30MB_GPUFull.patch、その後git apply。単体AutoCine Gitでは-p2を追加。
- 完全版は旧版と別フォルダへ展開。設定/録画は削除しない。
- 内容・実機確認: docs/CODEX_INTEGRATION_v51026_JA.md、docs/WINDOWS_TEST_v51026_JA.md、docs/CAMERAQA_30MB_DEV_JA.md。
