# v5.10.5 UIとカメラ通信の安全な統合の差分

- 基準: `codex/lol-autocine-v5104-handoff`（v5.10.4 GPUFX Capture60）
- 変更ファイル: このZIPに含まれる `LoL_AutoCine/` 以下
- Git推奨: 既存変更をコミットしてから差分を検査して適用する。GitHub取得用リポジトリのルートでは `git apply --check CHANGES_v5.10.5_ResponsiveUI.patch` → `git apply CHANGES_v5.10.5_ResponsiveUI.patch`。
- AutoCine単体のGitルート（直下にcore/やSTART.batがある構成）では `git apply --check -p2 CHANGES_v5.10.5_ResponsiveUI.patch` → `git apply -p2 CHANGES_v5.10.5_ResponsiveUI.patch`。
- 今回は旧説明書の移動/旧パスの削除が含まれる。Gitのパッチで適用するか、新しい完全版を別フォルダへ展開する。差分ZIPのファイルコピーだけでは古い説明書が残る。
- Codexが別途編集した `core/effects.py`、`core/gpu_pipeline.py`、`core/jobs.py`、`core/camera.py` 等はコンフリクト確認必須
- 音声のProcess Loopback、NVENC、TargetLock、UI設定の回帰テストを実施
- Windows/LoL/NVIDIA実機テストは配布前のLinux CIとは別に行う
