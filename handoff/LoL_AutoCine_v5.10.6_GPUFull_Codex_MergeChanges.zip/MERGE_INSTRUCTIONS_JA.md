# v5.10.6 GPU映像処理とホットフィックスの統合の差分

- 基準: `codex/lol-autocine-v5105-responsive-ui-handoff`（v5.10.5 GPUFX Capture60）
- 変更ファイル: このZIPに含まれる `LoL_AutoCine/` 以下
- Git推奨: 既存変更をコミットしてから差分を検査して適用する。GitHub取得用リポジトリのルートでは `git apply --check CHANGES_v5.10.6_GPUFull.patch` → `git apply CHANGES_v5.10.6_GPUFull.patch`。
- AutoCine単体のGitルート（直下にcore/やSTART.batがある構成）では `git apply --check -p2 CHANGES_v5.10.6_GPUFull.patch` → `git apply -p2 CHANGES_v5.10.6_GPUFull.patch`。
- 今回はGPU映像エンジンと受領ホットフィックスを追加。変更検査後にGitパッチで適用するか、新しい完全版を別フォルダへ展開する。
- Codexが別途編集した `core/effects.py`、`core/gpu_pipeline.py`、`core/jobs.py`、`core/camera.py` 等はコンフリクト確認必須
- 音声のProcess Loopback、NVENC、TargetLock、UI設定の回帰テストを実施
- Windows/LoL/NVIDIA実機テストは配布前のLinux CIとは別に行う
