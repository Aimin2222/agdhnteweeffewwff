# v5.10.15 PortraitCrashFix / GPUFull の差分

- 基準: codex/lol-autocine-v51015-ui-scan-camera-handoff（前回Codex統合v5.10.15）。別版への単純上書きはしない。
- GPU側core/kill_icons.pyの画像ID取得APIをPlayerと辞書の両形式へ対応。GPU/音声/カメラ/UI処理は保持。
- 変更をコミットしてからgit apply --check CHANGES_v5.10.15_PortraitCrashFix_GPUFull.patch、続いてgit applyで適用。
- 単体AutoCineのGitルートでは上記2コマンドに-p2を追加。
- 全体を取得する場合は完全版ZIPを旧版と別フォルダへ展開。設定/録画/プロジェクトを削除しない。
- Windows実機テスト: docs/WINDOWS_TEST_PORTRAITFIX_v51015_JA.md。
