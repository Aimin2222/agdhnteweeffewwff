from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
from PIL import Image
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb')
sys.path.insert(0,str(OLD/'work/runtime'))
import cv2
cv2.setNumThreads(1)
BASE=Path('LoL_AutoCine/assets/kill_frames_chatgpt')
def read(p):return json.loads(p.read_text('utf-8-sig'))
plan=read(OLD/'work/audit'/BASE/'full_production_v5/production.json')
audit=read(OLD/'outputs/complete_review_20261018/PORTRAIT_INTERIOR_AUDIT_20261019.json')
bykey={x['key']:x for x in plan['assets']};rows=[]
for a in audit['assets']:
 if not a['estimated_safe_interior_warning'] and not a['holes_not_detected']:continue
 asset=bykey[a['key']];p=OLD/'work/audit'/asset['output'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==a['frame_sha256']
 alpha=np.asarray(Image.open(p).getchannel('A'));h,w=alpha.shape
 solid=cv2.morphologyEx((alpha>25).astype('uint8'),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 n,labels,stats,centers=cv2.connectedComponentsWithStats(1-solid,8);sides=[]
 for side in range(2):
  candidates=[]
  for i,(x,y,bw,bh,area) in enumerate(stats[1:],1):
   cx,cy=centers[i]
   if x<=0 or y<=0 or x+bw>=w or y+bh>=h or area<w*h*.015:continue
   if (cx<w*.35 if side==0 else cx>w*.65):candidates.append((int(area),i))
  if not candidates:sides.append(dict(side=side,detected=False));continue
  _,i=max(candidates);dist=cv2.distanceTransform((labels==i).astype('uint8'),cv2.DIST_L2,5);safe=dist>max(12,round(w*.01));v=alpha[safe];vals,counts=np.unique(v[v>0],return_counts=True)
  ys,xs=np.where(safe&(alpha>0))
  sides.append(dict(side=side,detected=True,nonzero_pixels=int(len(xs)),alpha_histogram={str(int(vv)):int(cc) for vv,cc in zip(vals,counts)},residue_bbox=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None))
 rows.append(dict(key=a['key'],sha256=a['frame_sha256'],sides=sides,final_approved=False))
out=Path('outputs/recovery_20261019');out.mkdir(parents=True,exist_ok=True)
hist=collections.Counter()
for a in rows:
 for s in a['sides']:hist.update(s.get('alpha_histogram',{}))
report=dict(method=audit['method'],count=len(rows),global_residue_histogram=hist,automatic_removal_performed=False,final_approved=0,assets=rows)
(out/'PORTRAIT_RESIDUE_CHARACTERIZATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(dict(count=len(rows),histogram=hist),ensure_ascii=False))
