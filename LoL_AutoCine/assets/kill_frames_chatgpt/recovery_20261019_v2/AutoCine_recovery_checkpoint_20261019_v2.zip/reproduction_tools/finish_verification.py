from pathlib import Path
import json,hashlib,collections,math
import numpy as np
from PIL import Image,ImageDraw
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');AUDIT=OLD/'work/audit';BASE=Path('LoL_AutoCine/assets/kill_frames_chatgpt');OUT=Path('outputs/recovery_20261019');V2=OUT/'083_a_simple_vector_v2'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
plan=read(AUDIT/BASE/'full_production_v5/production.json');sources={};refs=[]
for a in plan['assets']:
 p=AUDIT/a['reference'];assert sha(p)==a['reference_sha256'];refs.append(dict(key=a['key'],sha256=a['reference_sha256']))
 path=a['source_reference']
 if path not in sources:
  p=AUDIT/path;assert sha(p)==a['source_sha256'];sources[path]=a['source_sha256']
assert len(sources)==89
effect=read(OLD/'outputs/complete_review_20261018/ABCD_D_theme_audit.json');layers=0
for a in effect['assets']:
 assert sha(AUDIT/a['peak_texture'])==a['peak_sha256']
 for b in a['existing_layers']:
  assert sha(AUDIT/b['file'])==b['sha256'];layers+=1
save(OUT/'SOURCE_AND_EFFECT_INTEGRITY.json',dict(originals_verified=len(sources),source_sha256=sources,reference_crops_verified=len(refs),references=refs,peak_textures_verified=len(effect['assets']),layer_registrations_verified=layers,originals_modified=False))
old=Image.open(OLD/'outputs/complete_review_20261018/review/083_a_simple_vector/candidate.png').convert('RGBA');new=Image.open(V2/'candidate.png').convert('RGBA');src=Image.open(OLD/'work/a_simple_main_crop.png').convert('RGB');assert new.size==(2520,1050)
arr=np.array(new);alpha=arr[:,:,3];h,w=alpha.shape;yy,xx=np.indices(alpha.shape);sides=[]
for cx in (88,333):
 mask=(xx/6-cx)**2+(yy/6-87.5)**2<55.5**2
 sides.append(dict(center_source=[cx,87.5],diagnostic_radius_source=55.5,pixels=int(mask.sum()),nonzero=int(np.count_nonzero(alpha[mask])),max_alpha=int(alpha[mask].max())))
edge=np.concatenate((alpha[0],alpha[-1],alpha[:,0],alpha[:,-1]));assert not edge.any() and all(x['nonzero']==0 for x in sides)
# Compare only stable ring interiors; this metric never approves shape, connector or X fidelity.
sm=np.asarray(src,dtype=float);oldsm=np.asarray(old.resize((420,175),Image.Resampling.LANCZOS),dtype=float);newsm=np.asarray(new.resize((420,175),Image.Resampling.LANCZOS),dtype=float)
y,x=np.indices((175,420));mask=np.zeros((175,420),dtype=bool)
for cx in (88,333):
 r=np.hypot(x-cx,y-87.5);mask|=(r>=58)&(r<=61)
error={}
for name,a in [('previous',oldsm),('revision',newsm)]:
 valid=mask&(a[:,:,3]>240);error[name]=dict(sample_pixels=int(valid.sum()),ring_rgb_mae=float(np.abs(a[:,:,:3][valid]-sm[valid]).mean()))
qa=dict(status='review_not_final',final_approved=False,sha256=sha(V2/'candidate.png'),mode=new.mode,dimensions=new.size,outer_edge_nonzero=int(np.count_nonzero(edge)),portrait_diagnostics=sides,ring_color_metric=error,metric_scope='RGB error at source resolution on annulus r58..61; not geometry/material/final approval.',visual_findings=['Ring hue and highlight position closer to source than prior vector; color metric is limited to sampled ring band.','Connector paths and center X remain inherited approximations; center X metal shading remains flatter than source.','Small sector/radial band texture is derived from low-resolution source sampling, not new high-resolution detail.'],old_candidate_unchanged=True,motion_status='not_generated_for_new_sha; previous motion not inherited')
save(V2/'qa.json',qa)
board=Image.new('RGB',(1290,650),'#202630');d=ImageDraw.Draw(board)
for col,title in enumerate(('SOURCE (420x175)','PREVIOUS VECTOR','REVISED VECTOR v2')):d.text((col*430+10,10),title,fill='white')
for row,bg in enumerate(((0,0,0),(128,128,128),(255,255,255))):
 for col,im in enumerate((src.convert('RGBA'),old,new)):
  cell=Image.new('RGBA',(420,175),bg+(255,));thumb=im.resize((420,175),Image.Resampling.LANCZOS);cell.alpha_composite(thumb);board.paste(cell.convert('RGB'),(col*430+5,40+row*200))
board.save(V2/'comparison.png')
summary=read(OUT/'RECOVERY_VERIFIED.json');summary.update(originals_verified=89,reference_crops_verified=652,ABCD_designs=4,D_themes=31,peak_textures_verified=35,layer_registrations_verified=layers,new_review_candidates=1,strict_final_approved=0)
save(OUT/'RECOVERY_VERIFIED.json',summary)
print(json.dumps(dict(summary=summary,vector_qa=qa),ensure_ascii=True))
