from pathlib import Path
import json,hashlib,zipfile,collections,shutil,time
import numpy as np
from PIL import Image
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb')
REVIEW=OLD/'outputs/complete_review_20261018'
BASE=Path('LoL_AutoCine/assets/kill_frames_chatgpt')
AUDIT=OLD/'work/audit'
OUT=Path('outputs/recovery_20261019');OUT.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text('utf-8-sig'))
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8')
metadata=[]
for a in read(Path('work/remote_listing.json')):
 if a['type']!='file':continue
 p=REVIEW/a['name']
 if not p.exists(): metadata.append(dict(path=a['path'],verified=False,error='local missing'));continue
 b=p.read_bytes();ok=blob(b)==a['sha'] and len(b)==a['size']
 metadata.append(dict(path=a['path'],verified=ok,sha256=digest(b),git_blob=blob(b)))
 if ok:
  target=Path('work/restored')/a['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
assert all(a['verified'] for a in metadata),metadata
for i in (1,2):
 family='review' if i==1 else 'variants'
 for a in read(Path(f'work/remote_meta{i}.json'))['tree']:
  if a['type']!='blob':continue
  p=REVIEW/family/a['path']
  # Variant was previously generated in delivery, not under variants locally.
  if not p.exists() and family=='variants':
   options=list((REVIEW/'delivery').rglob(Path(a['path']).name))
   p=next((x for x in options if blob(x.read_bytes())==a['sha']),p)
  if not p.exists():
   options=list((OLD/'outputs').rglob(Path(a['path']).name))
   p=next((x for x in options if x.is_file() and blob(x.read_bytes())==a['sha']),p)
  if not p.exists():metadata.append(dict(path=f'{family}/{a["path"]}',verified=False,error='local missing'));continue
  b=p.read_bytes();ok=blob(b)==a['sha'];metadata.append(dict(path=f'{family}/{a["path"]}',verified=ok,sha256=digest(b)))
  if ok:
   t=Path('work/restored')/BASE/'complete_review_20261018'/family/a['path'];t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
v5=read(Path('work/remote_meta0.json'))
for name in ('production.json','LATEST_REVIEW_STATUS_20261017_JA.md'):
 a=next(x for x in v5 if x['name']==name);p=AUDIT/BASE/'full_production_v5'/name
 b=read(Path('work/latest_status_remote.json'))['content'].encode('utf-8') if name.startswith('LATEST_') else p.read_bytes()
 assert blob(b)==a['sha'],name
 t=Path('work/restored')/a['path'];t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
 metadata.append(dict(path=a['path'],verified=True,sha256=digest(b)))
save('metadata_verification.json',metadata)
print('Metadata verified',sum(a['verified'] for a in metadata),'of',len(metadata),flush=True)
manifest=read(REVIEW/'ARCHIVE_MANIFEST.json');remote={a['path']:a for a in read(Path('work/remote_archives.json'))['tree']};assert len(remote)==len(manifest['packages'])==196
archives=[];entry_count=0;file_families=collections.Counter()
for pack in manifest['packages']:
 p=REVIEW/'archives'/pack['file'];b=p.read_bytes();ra=remote[pack['file']]
 assert digest(b)==pack['sha256'] and blob(b)==ra['sha'] and len(b)==pack['bytes']==ra['size'],str(p)
 with zipfile.ZipFile(p) as z:
  assert set(z.namelist())==set(e['entry'] for e in pack['entries']),str(p)
  for e in pack['entries']:
   content=z.read(e['entry']);assert len(content)==e['bytes'] and digest(content)==e['sha256'],e['entry']
   entry_count+=1;file_families[Path(e['entry']).suffix]+=1
 archives.append(dict(file=pack['file'],family=pack['family'],bytes=len(b),sha256=digest(b),git_blob=ra['sha'],entries=len(pack['entries']),verified=True))
 if len(archives)%25==0:print('ZIP verified',len(archives),'entries',entry_count,flush=True)
save('archive_verification.json',dict(commit='055f96f708ecb70175d122f1ec04c33847ed7335',method='Local bytes hashed against current GitHub Git blob IDs and manifest SHA-256; all ZIP entries read and CRC/SHA checked. No fresh binary network download.',count=len(archives),entries=entry_count,extensions=file_families,archives=archives))
plan=read(AUDIT/BASE/'full_production_v5/production.json');status=read(REVIEW/'candidate_status.json');portrait=read(REVIEW/'PORTRAIT_INTERIOR_AUDIT_20261019.json');portraits={a['key']:a for a in portrait['assets']}
frames=[];warnings=[];sources={}
for a in plan['assets']:
 p=AUDIT/a['output'];b=p.read_bytes();assert digest(b)==a['sha256'];im=Image.open(p);im.load();assert im.mode=='RGBA' and max(im.size)>=2048
 alpha=np.array(im.getchannel('A'));edge=np.concatenate((alpha[0],alpha[-1],alpha[:,0],alpha[:,-1]));v=portraits[a['key']];assert v['frame_sha256']==a['sha256']
 r=dict(key=a['key'],sha256=a['sha256'],dimensions=im.size,edge_nonzero=int(np.count_nonzero(edge)),alpha1_pixels=int(np.count_nonzero(alpha==1)),min_positive_alpha=int(alpha[alpha>0].min()),estimated_hole_warning=v['estimated_safe_interior_warning'],holes_undetected=v['holes_not_detected'],final_approved=False)
 frames.append(r)
 if v['estimated_safe_interior_warning'] or v['holes_not_detected']:warnings.append(r)
 sources[a['source_sha256']]=a.get('source')
save('frame_verification.json',dict(count=len(frames),frames=frames))
save('portrait_followup_queue.json',dict(diagnostic_only=True,final_approved=0,count=len(warnings),assets=warnings))
summary=dict(commit='055f96f708ecb70175d122f1ec04c33847ed7335',metadata_verified=sum(a['verified'] for a in metadata),metadata_missing=[a for a in metadata if not a['verified']],archives_verified=len(archives),archive_entries_verified=entry_count,current_png_verified=len(frames),comparison_mp4=sum(1 for a in read(REVIEW/'OUTPUT_LOCATIONS.json')['assets'] for f in a['files'] if f['entry'].endswith('.mp4')),final_approved=0,shape_repair=sum(a['shape_repair'] for a in status),edge_repair=sum(a['edge_nonzero']>0 for a in frames),repair_union=sum(a['shape_repair'] or a['edge_nonzero']>0 for a in status),estimated_hole_alpha_warnings=sum(a['estimated_hole_warning'] for a in frames),undetected_holes_frames=sum(a['holes_undetected']>0 for a in frames),alpha1_frames=sum(a['alpha1_pixels']>0 for a in frames),alpha1_pixels=sum(a['alpha1_pixels'] for a in frames))
save('RECOVERY_VERIFIED.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
