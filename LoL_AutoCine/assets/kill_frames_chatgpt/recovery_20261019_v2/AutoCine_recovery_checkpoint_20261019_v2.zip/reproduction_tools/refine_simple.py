from pathlib import Path
import json,hashlib,math,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb')
ROOT=Path('outputs/recovery_20261019/083_a_simple_vector_v2');ROOT.mkdir(parents=True,exist_ok=True)
source=OLD/'work/a_simple_main_crop.png';s=np.asarray(Image.open(source).convert('RGB'),dtype=float)
assert hashlib.sha256(source.read_bytes()).hexdigest()=='851a49e31888ed575145abd0d7a5fbcecad4c57ce7a8b3017c59a76a2b6968ba'
previous=OLD/'outputs/complete_review_20261018/review/083_a_simple_vector/frame.svg'
ET.register_namespace('','http://www.w3.org/2000/svg')
tree=ET.fromstring(previous.read_text('utf-8'));ns='{http://www.w3.org/2000/svg}'
# Retain the previous connectors and X paths; rebuild only the two circular ring groups.
parts=[ET.tostring(child,encoding='unicode') for child in tree if not (child.tag==ns+'g' and child.get('fill')=='none' and not child.get('stroke'))]
def sample(x,y):
 x=max(0,min(s.shape[1]-2,x));y=max(0,min(s.shape[0]-2,y));ix,iy=int(x),int(y);fx,fy=x-ix,y-iy
 return s[iy,ix]*(1-fx)*(1-fy)+s[iy,ix+1]*fx*(1-fy)+s[iy+1,ix]*(1-fx)*fy+s[iy+1,ix+1]*fx*fy
arcs=[]
for cx in (88,333):
 cy=87.5
 # Material colors sampled only from the ring band. No portrait raster is embedded.
 for band in range(10):
  ri=56.8+band*.57;ro=min(62.52,ri+.69);rm=ri+.285
  for sector in range(180):
   a0=sector*math.tau/180;a1=(sector+1)*math.tau/180+.0036;am=(sector+.5)*math.tau/180
   col=np.mean([sample(cx+rm*math.cos(am+d),cy+rm*math.sin(am+d)) for d in (-.008,0,.008)],axis=0).round().clip(0,255).astype(int)
   points=[(cx+rr*math.cos(aa),cy+rr*math.sin(aa)) for rr,aa in ((ro,a0),(ro,a1),(ri,a1),(ri,a0))]
   path='M'+' L'.join(f'{x:.4f} {y:.4f}' for x,y in points)+' Z'
   arcs.append(f'<path d="{path}" fill="#{col[0]:02x}{col[1]:02x}{col[2]:02x}"/>')
svg='<svg xmlns="http://www.w3.org/2000/svg" width="2520" height="1050" viewBox="0 0 420 175">\n'+'\n'.join(parts+arcs)+'\n</svg>\n'
(ROOT/'frame.svg').write_text(svg,'utf-8')
meta=dict(key='083/a_simple_main',status='review_not_final',final_approved=False,adopted_into_current_652=False,source_reference_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),previous_svg_sha256=hashlib.sha256(previous.read_bytes()).hexdigest(),method='Existing SVG revision. Ring inner radius 56.8, outer radius 62.52 in source coordinates; ring material RGB sampled in 10 radial bands / 180 sectors. Connectors and X retained. No source raster or portrait embedded.',limitations=['Source is 420x175; output pixel dimensions do not prove independent high-resolution painted detail.','Circular geometry is a controlled approximation, not a pixel-perfect source trace.','Connectors and X still require final geometry/material comparison.','No motion regenerated or old motion approval carried over.'])
(ROOT/'provenance.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf-8')
print('SVG revision saved',len(svg.encode('utf-8')),'bytes')
