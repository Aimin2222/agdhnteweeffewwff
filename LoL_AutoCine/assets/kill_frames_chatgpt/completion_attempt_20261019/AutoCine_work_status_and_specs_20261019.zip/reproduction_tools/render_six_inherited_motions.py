from pathlib import Path
import json,hashlib,math,subprocess
from PIL import Image,ImageDraw
OUT=Path('outputs/finish_20261019');source=Path('outputs/continuation_20261019/083_a_simple_vector_v3/candidate.png');source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert source_sha=='a9cdf1c17bc8fc3ff6a20b627ca31e53f8edd2babd10ee5ea82342a53dcf5c6e'
FF=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb\work\runtime-bin\ffmpeg.exe')
spec=json.loads((OUT/'SIX_MOTION_RECOVERED.json').read_text('utf-8'));sprite=Image.open(source).convert('RGBA').resize((480,200),Image.Resampling.LANCZOS);records=[]
for mode in spec['modes']:
 key=mode['id'];folder=OUT/'six_motion_review'/key;folder.mkdir(parents=True,exist_ok=True);dest=folder/'comparison.mp4';assert not dest.exists()
 proc=subprocess.Popen([str(FF),'-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate','30','-i','pipe:0','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-an','-frames:v','90',str(dest)],stdin=subprocess.PIPE,stderr=subprocess.PIPE)
 frames=[];positions=[]
 for n in range(90):
  t=n/30;visible=.2<=t<1.85;x,y=768.,62.;elapsed=max(0,t-.2);u=max(0,min(1,1-elapsed/.260));ease=u*u*(3-2*u)
  if key=='slide_left':x-=1300*ease
  elif key=='slide_right':x+=1300*ease
  elif key=='slide_up':y+=740*ease
  elif key=='slide_down':y-=740*ease
  elif key=='pop':x+=16*math.exp(-18*elapsed)*math.cos(28*elapsed)
  transparent=Image.new('RGBA',(1280,720),(0,0,0,0))
  if visible:transparent.alpha_composite(sprite,(round(x),round(y)))
  frames.append(transparent);positions.append(dict(frame=n,time=t,x=x,y=y,visible=visible))
  bg=Image.new('RGBA',(1280,720),(19,27,38,255));bg.alpha_composite(transparent);rgb=bg.convert('RGB');proc.stdin.write(rgb.tobytes())
  if n==17:rgb.save(folder/'poster.png')
 proc.stdin.close();error=proc.stderr.read().decode('utf-8','replace');rc=proc.wait();assert rc==0,error
 frames[0].save(folder/'effect_alpha.webp',save_all=True,append_images=frames[1:],duration=[33,33,34]*30,loop=0,lossless=True,method=4)
 # Decode the whole MP4; one framemd5 record per decoded frame.
 check=subprocess.run([str(FF),'-v','error','-i',str(dest),'-f','framemd5','-'],capture_output=True,check=True)
 decoded=[a for a in check.stdout.decode().splitlines() if a and not a.startswith('#')];assert len(decoded)==90
 wp=Image.open(folder/'effect_alpha.webp');duration=0
 for i in range(wp.n_frames):wp.seek(i);wp.load();duration+=wp.info.get('duration',0)
 assert duration==3000,(key,duration)
 wp.seek(0);assert not wp.convert('RGBA').getchannel('A').getbbox();wp.seek(wp.n_frames-1);assert not wp.convert('RGBA').getchannel('A').getbbox()
 files=[]
 for p in (dest,folder/'effect_alpha.webp',folder/'poster.png'):files.append(dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 motion=dict(id=key,label=mode['label'],source_frame_sha256=source_sha,source_frame_path=source.as_posix(),source_frame_status='review_not_final',technical_definition_commit=spec['technical_commit'],canvas=[1280,720],fps=30,frames=90,duration_seconds=3,kill_time=.3,enter_start=.2,visible_end=1.85,display_dimensions=[480,200],base_position=[768,62],opacity=1,rotation=0,scale_animation=False,frame_shape_unchanged=True,scope='Offline six existing entrance designs on No.083 review frame. No game/GPU/652 integration claim.',decoded_mp4_frames=len(decoded),webp_decoded_frames=wp.n_frames,webp_total_duration_ms=duration,first_and_last_alpha_zero=True,final_approved=False,files=files,positions=positions)
 (folder/'motion.json').write_text(json.dumps(motion,ensure_ascii=False,indent=2),'utf-8');records.append({k:v for k,v in motion.items() if k!='positions'});print('Rendered and decoded',key,flush=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
(OUT/'SIX_MOTION_RENDER_QA.json').write_text(json.dumps(dict(count=6,status='review_not_final',frame_sha256=source_sha,all_mp4_decoded_90_frames=True,all_webp_3000ms=True,source_frame_unchanged=True,assets=records),ensure_ascii=False,indent=2),'utf-8')
