from pathlib import Path
import json,hashlib
from PIL import Image
OUT=Path('outputs/finish_20261019');OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');BASE='LoL_AutoCine/assets/kill_frames_chatgpt/'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,d):(OUT/name).write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
v1=read(Path('outputs/continuation_20261019/PEAK_ALPHA1_ALL35_QA.json'));v2=read(OUT/'PEAK_MARGIN23_QA.json');overrides={a['id']:a for a in v2['assets']};peaks=[]
for a in v1['assets']:
 b=overrides.get(a['id']);path=BASE+'completion_attempt_20261019/'+b['output'] if b and b['output'] else BASE+'continuation_20261019_v3/'+a['output'];digest=b['output_sha256'] if b else a['output_sha256'];edge=b['edge_after'] if b else a['edge_nonzero_after']
 peaks.append(dict(id=a['id'],repository_path=path,sha256=digest,edge_nonzero=edge,dimensions=a['dimensions'],native_2k=a['native_2k'],final_approved=False,motion_for_this_peak_sha='not_rendered; previous motion not inherited'))
write('LATEST_PEAK_SET.json',dict(count=35,edge_clean=sum(a['edge_nonzero']==0 for a in peaks),edge_warning=sum(a['edge_nonzero']>0 for a in peaks),below_native_2k=sum(not a['native_2k'] for a in peaks),final_approved=0,assets=peaks))
plan=read(OLD/'work/audit'/Path(BASE)/'full_production_v5/production.json');sources={};candidate_count=0
for a in plan['assets']:
 p=OLD/'work/audit'/a['output'];assert sha(p)==a['sha256'];candidate_count+=1
 p=OLD/'work/audit'/a['source_reference']
 if a['source_reference'] not in sources:
  assert sha(p)==a['source_sha256'];sources[a['source_reference']]=a['source_sha256']
assert len(sources)==89 and candidate_count==652
write('PROTECTED_INPUT_INTEGRITY.json',dict(originals_verified=89,candidates_verified=652,all_originals_and_candidates_unchanged=True,sources=sources))
limitations=[]
for a in plan['assets']:
 if not a['source_partial'] and not a['palette_reference']:continue
 ref=OLD/'work/audit'/a['reference'];assert sha(ref)==a['reference_sha256'];im=Image.open(ref)
 limitations.append(dict(key=a['key'],source=a['source_reference'],source_sha256=a['source_sha256'],reference=a['reference'],reference_sha256=a['reference_sha256'],reference_dimensions=im.size,crop_box=a['reference_crop_box'],reason='source image is cut off' if a['source_partial'] else 'small palette reference cannot establish all high-resolution shape/material details',required_to_close='complete source/authoring data or explicit separate reconstruction-design decision; never silently count as faithful final',final_approved=False))
write('SOURCE_LIMITATIONS_REQUIRED_INPUT.json',dict(count=len(limitations),source_partial=8,palette_reference=11,user_response_record='No complete source location supplied; user replied none known/depends on which image. Original No.004 was displayed without modification.',assets=limitations))
summary=dict(complete=False,work_visual_production_complete=False,final_approved=0,current_candidates=652,known_repair_union=319,final_unverified_without_previous_shape_or_edge_flags=333,new_generation_attempts=2,new_generation_accepted=0,latest_peak_edge_warning=3,latest_peak_below_native_2k=31,source_partial=8,palette_reference=11,six_motion_definitions_recovered=True,six_motion_offline_review_sets_rendered=6,source_frame_for_six_motions='083/a_simple_main vector v3 review_not_final',full_652_game_integration_claimed=False,blocking_conditions=['Eight original references are themselves incomplete and no complete version was supplied.','Eleven small palette-only references do not establish all high-resolution detail.','Existing shape differences and transparency defects are unresolved; the two new generative attempts did not meet fidelity/native-size criteria.','31 peak native resolutions remain below 2048, independent theme art remains incomplete.'],next_decision='Continue targeted artistic correction with adequate source/authoring material; do not downgrade fidelity or relabel incomplete materials as final.')
write('WORK_COMPLETION_STATUS.json',summary);print(json.dumps(summary,ensure_ascii=True))
