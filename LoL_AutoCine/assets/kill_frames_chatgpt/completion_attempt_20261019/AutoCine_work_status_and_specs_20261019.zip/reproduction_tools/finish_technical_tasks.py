from pathlib import Path
import json,hashlib,sys,ast
import numpy as np
from PIL import Image,ImageDraw
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');sys.path.insert(0,str(OLD/'work/runtime'))
import cv2
cv2.setNumThreads(1)
OUT=Path('outputs/finish_20261019');OUT.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
# Exact prior distance/connected-component rule, applied only where peak residue remains.
audit=read(Path('outputs/continuation_20261019/PEAK_ALPHA1_ALL35_QA.json'));rows=[]
for a in audit['assets']:
 if not a['edge_nonzero_after']:continue
 source=Path('outputs/continuation_20261019')/a['output'];assert sha(source)==a['output_sha256'];im=Image.open(source);im.load();before=np.array(im);alpha=before[:,:,3]
 distance=cv2.distanceTransform((alpha<4).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);protected=distance<=24
 n,labels,stats,_=cv2.connectedComponentsWithStats(((alpha>=2)&(alpha<=3)).astype('uint8'),connectivity=8)
 touches=np.bincount(labels[protected],minlength=n)>0
 eligible=(stats[:,cv2.CC_STAT_AREA]<=64)&(stats[:,cv2.CC_STAT_WIDTH]<=8)&(stats[:,cv2.CC_STAT_HEIGHT]<=8)&~touches;eligible[0]=False;mask=eligible[labels];count=int(mask.sum())
 dest=None;after=before.copy();after[:,:,3][mask]=0
 if count:
  dest=OUT/'peak_margin23_v1'/a['id']/'impact_rgba.png';dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
  Image.fromarray(after,'RGBA').save(dest,compress_level=9,**{k:im.info[k] for k in ('icc_profile','exif','dpi') if k in im.info})
  result=Image.open(dest);assert np.array_equal(np.array(result),after)
  for k in ('icc_profile','gamma','srgb','chromaticity'):assert result.info.get(k)==im.info.get(k)
 assert np.array_equal(after[:,:,:3],before[:,:,:3]) and np.array_equal(after[protected],before[protected]) and sha(source)==a['output_sha256']
 aa=after[:,:,3];edge=np.r_[aa[0],aa[-1],aa[:,0],aa[:,-1]]
 rows.append(dict(id=a['id'],input_sha256=a['output_sha256'],input=source.as_posix(),output=dest.relative_to(OUT).as_posix() if dest else None,output_sha256=sha(dest) if dest else a['output_sha256'],removed_pixels=count,eligible_components=int(eligible.sum()),edge_before=a['edge_nonzero_after'],edge_after=int(np.count_nonzero(edge)),remaining_edge_alpha_values=np.unique(edge[edge>0]).astype(int).tolist(),all_rgb_unchanged=True,all_protected_pixels_unchanged=True,final_approved=False))
write(OUT/'PEAK_MARGIN23_QA.json',dict(authorization='full_production_v5/qa/margin_dot_distance_rule_authorization_20261017.json',count=len(rows),modified_files=sum(a['removed_pixels']>0 for a in rows),removed_pixels=sum(a['removed_pixels'] for a in rows),remaining_edge_warning=sum(a['edge_after']>0 for a in rows),final_approved=0,assets=rows))
# Record both generation failures without upscaling or automatic adoption.
attempts=[]
for intensity in ('weak','strong'):
 folder=OUT/'review'/f'001_elderwood_{intensity}_attempt1';p=folder/'raw_generated.png';im=Image.open(p);im.load();alpha=np.array(im.getchannel('A'));edge=np.r_[alpha[0],alpha[-1],alpha[:,0],alpha[:,-1]]
 r=dict(key='001/elderwood_'+intensity,sha256=sha(p),mode=im.mode,dimensions=im.size,long_edge_at_least_2048=max(im.size)>=2048,edge_nonzero=int(np.count_nonzero(edge)),alpha1_pixels=int(np.count_nonzero(alpha==1)),status='rejected_not_final',final_approved=False,adopted=False,method='built-in image_gen, transparent background',visual_rejection=['Native output long edge below 2048 despite explicit prompt; no upscaling used.','Central ornament/branch ratios remain different from original small source.','Generated thin ring/branch shape is a redesign approximation, not verified faithful reconstruction.'])
 write(folder/'qa.json',r);attempts.append(r)
write(OUT/'GENERATION_ATTEMPTS.json',dict(final_approved=0,rejected_count=len(attempts),assets=attempts))
# Recover six existing motion IDs and their immutable source/provenance; do not execute/edit app code.
code=read(Path('work/motion_source.json'));doc=read(Path('work/motion_approval_doc.json'));tree=ast.parse(code['content'])
modes=None
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MOTION_STYLES' for t in node.targets):modes=ast.literal_eval(node.value)
assert modes and len(modes)==6
motion=dict(technical_commit='de453046c2e2a7f522571e4d45d804947b05a150',source_path='LoL_AutoCine/core/kill_icons.py',source_blob=code['sha'],approval_record_path='LoL_AutoCine/docs/RECEIVED_IMPLEMENTATION_v51020_JA.md',approval_record_blob=doc['sha'],approval_scope='Technical document states user accepted six kill-frame entrances; this is an inherited record, not fresh user/video/GPU validation.',modes=[dict(id=k,label=v) for k,v in modes.items()],duration_seconds_slide=.260,smoothstep_u='clamp(1-(t-start)/0.260,0,1)',smoothstep='u*u*(3-2*u)',slide_distance='full canvas width+20 or height+20, matching existing CPU/OpenCL code',pop_offset_x='16*exp(-18*max(0,t-start))*cos(28*max(0,t-start))',pop_scale_rotation='none; existing pop is x-position only',integration_scope='Existing 37 badges; reuse of motion design does not prove integration/fidelity of the 652 review candidates.',app_code_modified=False)
write(OUT/'SIX_MOTION_RECOVERED.json',motion)
evidence=OUT/'evidence';evidence.mkdir(exist_ok=True)
(evidence/'SIX_MOTION_APPROVAL_RECORD.md').write_text(doc['content'],'utf-8')
lines=code['content'].splitlines();i=next(i for i,s in enumerate(lines) if s.startswith('MOTION_STYLES ='))
(evidence/'SIX_MOTION_SOURCE_EXCERPT.txt').write_text('\n'.join(lines[i:i+34])+'\n','utf-8')
# Exhaustive reference limitations / verification queue; never convert diagnostic passes to final approvals.
base=OLD/'work/audit/LoL_AutoCine/assets/kill_frames_chatgpt';plan=read(base/'full_production_v5/production.json');status=read(OLD/'outputs/complete_review_20261018/candidate_status.json');bykey={a['key']:a for a in status};review=[]
for a in plan['assets']:
 r=bykey[a['key']];review.append(dict(key=a['key'],frame_sha256=a['sha256'],source_partial=a['source_partial'],palette_reference=a['palette_reference'],known_shape_flag=r['shape_repair'],known_edge_flag=r['edge_nonzero']>0,existing_no_flags_not_final=not r['shape_repair'] and r['edge_nonzero']==0,estimated_hole_warning=r.get('estimated_portrait_interior_warning',False),final_approved=False,required='full source-fidelity inspection; source limitations preserved'))
write(OUT/'ALL_652_COMPLETION_GATES.json',dict(count=652,final_approved=0,no_flags_but_final_unverified=sum(a['existing_no_flags_not_final'] for a in review),source_partial_count=sum(a['source_partial'] for a in review),palette_reference_count=sum(a['palette_reference'] for a in review),assets=review))
print(json.dumps(dict(peaks=rows,rejected_attempts=attempts,motion_ids=list(modes),all_frames=len(review)),ensure_ascii=True))
