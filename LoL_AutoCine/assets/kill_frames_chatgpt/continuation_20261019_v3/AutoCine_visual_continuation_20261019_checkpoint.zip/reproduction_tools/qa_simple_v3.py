from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');OUT=Path('outputs/continuation_20261019');V3=OUT/'083_a_simple_vector_v3';V2=Path('outputs/recovery_20261019/083_a_simple_vector_v2');src=Image.open(OLD/'work/a_simple_main_crop.png').convert('RGBA');a=Image.open(V2/'candidate.png').convert('RGBA');b=Image.open(V3/'candidate.png').convert('RGBA')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
arr=np.array(b);alpha=arr[:,:,3];y,x=np.indices(alpha.shape);holes=[]
for cx in (88,333):
 mask=(x/6-cx)**2+(y/6-87.5)**2<56.5**2
 holes.append(dict(center=[cx,87.5],diagnostic_radius=56.5,pixels=int(mask.sum()),nonzero=int(np.count_nonzero(alpha[mask])),max_alpha=int(alpha[mask].max())))
edge=np.r_[alpha[0],alpha[-1],alpha[:,0],alpha[:,-1]];assert np.count_nonzero(edge)==0 and all(h['nonzero']==0 for h in holes)
old=np.array(a);ring=np.zeros(alpha.shape,dtype=bool)
for cx in (88,333):
 r=np.hypot(x/6-cx,y/6-87.5);ring|=(r>=57)&(r<=62.4)
# Connector/ring joins may overlap; central ring bands away from joins must be identical.
ring&=(y/6>40)&(y/6<135)
assert np.array_equal(arr[ring],old[ring]),'Unintended ring change'
s=np.array(src.resize((420,175)))[:,:,:3].astype(float);metrics={}
for name,im in [('v2',a),('v3',b)]:
 small=np.array(im.resize((420,175),Image.Resampling.LANCZOS));alpha_small=small[:,:,3];region=np.zeros((175,420),bool);region[67:114,188:235]=True;source_mask=(s.mean(2)>65)&region;mask=(alpha_small>128)&region
 union=np.count_nonzero(source_mask|mask);intersection=np.count_nonzero(source_mask&mask)
 interior=source_mask&(alpha_small>240)
 connector_region=np.zeros((175,420),bool);connector_region[27:35,150:290]=True;connector_region[139:148,150:290]=True
 source_bright=(s.mean(2)>70)&connector_region;pred=(alpha_small>128)&connector_region
 metrics[name]=dict(x_binary_iou_at_source_resolution=intersection/union,x_rgb_mae_on_shared_opaque_pixels=float(np.abs(s[interior]-small[:,:,:3][interior]).mean()),x_shared_opaque_pixels=int(interior.sum()),connector_bright_pixel_recall=float(np.count_nonzero(source_bright&pred)/np.count_nonzero(source_bright)),notes='Diagnostics against a composite source with threshold masks; not ground-truth alpha or final-quality approval.')
qa=dict(status='review_not_final',final_approved=False,sha256=sha(V3/'candidate.png'),mode=b.mode,dimensions=b.size,outer_edge_nonzero=0,portrait_hole_diagnostics=holes,unchanged_ring_band_verified=True,source_resolution_metrics=metrics,visual_findings=['X and connector measurements now follow source luminance and source positions.','Visible connector kink near ring joins and contour-derived X shading remain; further visual refinement is needed.','Source has composite background and small native size; alpha edge and exact ring geometry are not fully established.'],motion_status='Not rendered for new SHA; old motion not reused',adopted_into_current_652=False)
(V3/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),'utf-8')
board=Image.new('RGB',(1290,650),'#202630');d=ImageDraw.Draw(board)
for c,t in enumerate(('SOURCE (420x175)','VECTOR v2','VECTOR v3 - REVIEW')):d.text((c*430+8,10),t,fill='white')
for r,bg in enumerate(((0,0,0),(128,128,128),(255,255,255))):
 for c,im in enumerate((src,a,b)):
  cell=Image.new('RGBA',(420,175),bg+(255,));cell.alpha_composite(im.resize((420,175),Image.Resampling.LANCZOS));board.paste(cell.convert('RGB'),(c*430+5,40+r*200))
board.save(V3/'comparison.png')
print(json.dumps(qa,ensure_ascii=True))
