from pathlib import Path
import json,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');AUDIT=OLD/'work/audit';OUT=Path('outputs/continuation_20261019');OUT.mkdir(exist_ok=True,parents=True)
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
audit=read(OLD/'outputs/complete_review_20261018/ABCD_D_theme_audit.json');rows=[];diagnostics=[]
for a in audit['assets']:
 src=AUDIT/a['peak_texture'];before_sha=sha(src);assert before_sha==a['peak_sha256'];im=Image.open(src);im.load();before=np.array(im);alpha=before[:,:,3];edge=np.r_[alpha[0],alpha[-1],alpha[:,0],alpha[:,-1]]
 diagnostics.append(dict(id=a['id'],sha256=before_sha,dimensions=im.size,alpha1_pixels=int(np.count_nonzero(alpha==1)),edge_nonzero=int(np.count_nonzero(edge)),edge_alpha_values=np.unique(edge[edge>0]).astype(int).tolist(),long_edge_at_least_2048=max(im.size)>=2048))
 if '--all' not in sys.argv and a['id'] not in ('A','B','C','D'):continue
 dest=OUT/'peak_alpha1_v1'/a['id'];dest.mkdir(parents=True,exist_ok=True)
 after=before.copy();selected=alpha==1;after[:,:,3][selected]=0
 target=dest/'impact_rgba.png'
 options={k:im.info[k] for k in ('icc_profile','exif','dpi') if k in im.info}
 if not target.exists():Image.fromarray(after,'RGBA').save(target,compress_level=9,**options)
 check=Image.open(target);check.load();assert np.array_equal(np.array(check),after)
 assert np.array_equal(after[:,:,:3],before[:,:,:3]);assert np.array_equal(after[:,:,3][~selected],alpha[~selected]);assert sha(src)==before_sha
 for k in ('icc_profile','gamma','srgb','chromaticity'):assert check.info.get(k)==im.info.get(k),k
 e=after[:,:,3];ed=np.r_[e[0],e[-1],e[:,0],e[:,-1]]
 originalspec=AUDIT/a['specification'];spec=read(originalspec)
 # Preserve the historical spec verbatim, then expose the new texture as an explicit review override.
 if not (dest/'historical_spec.json').exists():(dest/'historical_spec.json').write_bytes(originalspec.read_bytes())
 override=dict(id=a['id'],status='review_not_final',source_peak=a['peak_texture'],source_peak_sha256=before_sha,source_spec=a['specification'],source_spec_sha256=sha(originalspec),review_peak='impact_rgba.png',review_peak_sha256=sha(target),timing_motion_colors='Unchanged historical spec; this override only identifies a separate alpha1 derivative',historical_animation_approval_inherited=False,new_motion_status='not_rendered_for_this_texture_sha',final_approved=False)
 if not (dest/'review_override.json').exists():(dest/'review_override.json').write_text(json.dumps(override,ensure_ascii=False,indent=2),'utf-8')
 rows.append(dict(id=a['id'],input_file=a['peak_texture'],input_sha256=before_sha,output=target.relative_to(OUT).as_posix(),output_sha256=sha(target),dimensions=im.size,removed_alpha1_pixels=int(selected.sum()),all_rgb_unchanged=True,all_other_alpha_unchanged=True,color_metadata_unchanged=True,input_unchanged=True,edge_nonzero_before=int(np.count_nonzero(edge)),edge_nonzero_after=int(np.count_nonzero(ed)),edge_values_after=np.unique(ed[ed>0]).astype(int).tolist(),native_2k=max(im.size)>=2048,final_approved=False))
report=dict(status='authorized_alpha1_derivatives_review_not_final',authorization='LoL_AutoCine/assets/kill_frames_chatgpt/full_production_v5/qa/alpha_cleanup_authorization_20261017.json',scope='A/B/C/D and D-theme original peak textures, saved to separate new files; no resize or source replacement',count=len(rows),removed_alpha1_pixels=sum(x['removed_alpha1_pixels'] for x in rows),edge_clean_after=sum(x['edge_nonzero_after']==0 for x in rows),final_approved=0,assets=rows,all_35_peak_diagnostics=diagnostics)
(OUT/('PEAK_ALPHA1_ALL35_QA.json' if '--all' in sys.argv else 'PEAK_ALPHA1_QA.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='all_35_peak_diagnostics'},ensure_ascii=True))
