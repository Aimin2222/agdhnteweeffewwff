const fs=require('node:fs');
const {createCanvas,loadImage}=require('C:/Users/saoan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');
(async()=>{const p='outputs/continuation_20261019/083_a_simple_vector_v3/';const im=await loadImage(fs.readFileSync(p+'frame.svg'));const c=createCanvas(2520,1050);c.getContext('2d').drawImage(im,0,0);fs.writeFileSync(p+'candidate.png',await c.encode('png'));console.log('Rendered v3');})();
