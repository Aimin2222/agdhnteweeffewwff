from pathlib import Path
import json,hashlib,math,sys,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb')
sys.path.insert(0,str(OLD/'work/runtime'))
import cv2
cv2.setNumThreads(1)
OUT=Path('outputs/continuation_20261019/083_a_simple_vector_v3');OUT.mkdir(parents=True,exist_ok=True)
src=OLD/'work/a_simple_main_crop.png';s=np.array(Image.open(src).convert('RGB'),dtype=float)
assert hashlib.sha256(src.read_bytes()).hexdigest()=='851a49e31888ed575145abd0d7a5fbcecad4c57ce7a8b3017c59a76a2b6968ba'
v2=Path('outputs/recovery_20261019/083_a_simple_vector_v2/frame.svg')
ET.register_namespace('','http://www.w3.org/2000/svg');tree=ET.fromstring(v2.read_text('utf-8'));ns='{http://www.w3.org/2000/svg}'
# The final 3600 paths are the previous sampled-color ring sectors. Preserve them exactly.
rings=list(tree)[-3600:];assert all(c.tag==ns+'path' and c.get('fill','').startswith('#') for c in rings)
lum=s.mean(2)
def col(v):return '#'+''.join(f'{int(q):02x}' for q in np.rint(v).clip(0,255))
defs=[];connectors=[];profile=[]
for name,y0,y1 in [('top',28,34),('bottom',140,146)]:
 points=[];stops=[]
 for x in range(112,311,4):
  values=lum[y0:y1,x];background=(lum[y0-3:y0,x].mean()+lum[y1:y1+3,x].mean())/2
  weights=np.maximum(0,values-background);peak=int(np.argmax(values))+y0
  fallback=30.5 if name=='top' else 142.8
  y=float((np.arange(y0,y1)*weights).sum()/weights.sum())+.5 if weights.sum()>10 else fallback
  y=float(np.clip(y,29.5,31.5) if name=='top' else np.clip(y,141.5,145.5))
  # Source pixels use integer centers; +.5 positions their energy on the SVG pixel grid.
  points.append((x+.5,y));stops.append(f'<stop offset="{(x-112)/198:.5f}" stop-color="{col(s[peak,x])}"/>')
  profile.append(dict(line=name,x=x,center=y,source_peak_y=peak,source_rgb=s[peak,x].astype(int).tolist()))
 defs.append(f'<linearGradient id="{name}" gradientUnits="userSpaceOnUse" x1="112" y1="0" x2="310" y2="0">'+''.join(stops)+'</linearGradient>')
 path='M'+' L'.join(f'{x:.3f} {y:.3f}' for x,y in points)
 connectors.append(f'<path d="{path}" fill="none" stroke="url(#{name})" stroke-width="2.6" opacity=".16"/>')
 connectors.append(f'<path d="{path}" fill="none" stroke="url(#{name})" stroke-width="1.35"/>')
# Trace the isolated central X at subpixel resolution. The threshold is confined to its source ROI.
x0,y0=184,63;roi=s[y0:118,x0:238];scalar=roi.mean(2).astype('float32');up=8
field=cv2.resize(scalar,None,fx=up,fy=up,interpolation=cv2.INTER_LINEAR)
def contours(level,only_largest=False):
 cs,_=cv2.findContours((field>=level).astype('uint8'),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 cs=[c for c in cs if cv2.contourArea(c)>up*up*.15]
 if only_largest:cs=[max(cs,key=cv2.contourArea)]
 result=[]
 for c in cs:
  c=cv2.approxPolyDP(c,.18*up,True).reshape(-1,2)
  result.append('M'+' L'.join(f'{x0+(x+.5)/up:.3f} {y0+(y+.5)/up:.3f}' for x,y in c)+' Z')
 return result
outline=contours(65,True)[0];defs.append(f'<clipPath id="x_shape"><path d="{outline}"/></clipPath>')
material=[f'<path d="{outline}" fill="#42536a"/>']
for level in range(68,251,2):
 mask=(scalar>=level)&(scalar<level+2)
 rgb=np.median(roi[mask],axis=0) if mask.any() else np.array([level*.9,level,level*1.1])
 for path in contours(level):material.append(f'<path d="{path}" fill="{col(rgb)}"/>')
xlayer='<g clip-path="url(#x_shape)">'+''.join(material)+'</g>'
svg='<svg xmlns="http://www.w3.org/2000/svg" width="2520" height="1050" viewBox="0 0 420 175">\n<defs>'+''.join(defs)+'</defs>\n'+''.join(connectors)+xlayer+''.join(ET.tostring(c,encoding='unicode') for c in rings)+'\n</svg>\n'
(OUT/'frame.svg').write_text(svg,'utf-8')
provenance=dict(key='083/a_simple_main',status='review_not_final',final_approved=False,adopted_into_current_652=False,source_reference_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),previous_svg_sha256=hashlib.sha256(v2.read_bytes()).hexdigest(),rings='Unchanged 3600 SVG ring sectors from v2',connectors='Source row-profile measured centerline and RGB; 1.35px stroke plus 16% 2.6px local halo; measured in 420x175 source coordinates',center_x='Largest luminance>=65 contour in central ROI only, subpixel interpolated trace; 2-level luminance contour fills, source-derived RGB; no raster embedded',limitations=['Source is only 420x175. Vector export is not independent new high-resolution painted detail.','Threshold trace cannot prove true source alpha; source has a composited background.','Ring boundaries are still fitted circles; exact radius/material fidelity remains under review.','No final approval, no adoption, no inherited animation approval.'],connector_measurements=profile)
(OUT/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),'utf-8')
print('SVG v3 created',len(svg.encode()),'bytes')
