from pathlib import Path
import json,sys,hashlib
import numpy as np
from PIL import Image
OLD=Path(r'C:\Users\saoan\Documents\Codex\2026-10-18\lol-autocine-work-windows-pc-usb');sys.path.insert(0,str(OLD/'work/runtime'))
import cv2
cv2.setNumThreads(1)
BASE=Path('LoL_AutoCine/assets/kill_frames_chatgpt')
def read(p):return json.loads(p.read_text('utf-8-sig'))
plan=read(OLD/'work/audit'/BASE/'full_production_v5/production.json');diag=read(Path('outputs/recovery_20261019/PORTRAIT_RESIDUE_CHARACTERIZATION.json'));bykey={a['key']:a for a in plan['assets']};rows=[]
for a in diag['assets']:
 src=OLD/'work/audit'/bykey[a['key']]['output'];assert hashlib.sha256(src.read_bytes()).hexdigest()==a['sha256']
 alpha=np.array(Image.open(src).getchannel('A'));distance=cv2.distanceTransform((alpha<4).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);protected=distance<=24
 weak=((alpha==2)|(alpha==3)).astype('uint8');n,labels,stats,_=cv2.connectedComponentsWithStats(weak,connectivity=8);touch=np.bincount(labels[protected],minlength=n)>0
 small=(stats[:,cv2.CC_STAT_AREA]<=64)&(stats[:,cv2.CC_STAT_WIDTH]<=8)&(stats[:,cv2.CC_STAT_HEIGHT]<=8);eligible=small&~touch;eligible[0]=False
 rows.append(dict(key=a['key'],sha256=a['sha256'],alpha23_pixels=int(weak.sum()),weak_components=n-1,components_too_large=int(np.count_nonzero(~small[1:])),components_touching_protected=int(np.count_nonzero(touch[1:])),eligible_components=int(eligible.sum()),eligible_pixels=int(np.count_nonzero(eligible[labels])),alpha_ge4_pixels_immutable=int(np.count_nonzero(alpha>=4)),input_modified=False,final_approved=False))
report=dict(count=len(rows),method='Re-evaluate exact authorized alpha2/3 rule: 8 connectivity, <=64px, <=8x8, no pixel <=24px from alpha>=4. Read only; no automatic hole-mask deletion.',eligible_frames=sum(a['eligible_pixels']>0 for a in rows),eligible_pixels=sum(a['eligible_pixels'] for a in rows),frames_with_alpha23=sum(a['alpha23_pixels']>0 for a in rows),final_approved=0,assets=rows)
Path('outputs/continuation_20261019/AUTHORIZED_ALPHA23_ELIGIBILITY.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='assets'}))
